import { configureStore } from '@reduxjs/toolkit'
import CommonDataSlice from "./Slices/CommonDataSlice";
import UserDataSlice from "./Slices/UserDataSlice";

const store = configureStore({
  reducer: {
    commonData : CommonDataSlice,
    userData : UserDataSlice,
  },
})

export default store;

