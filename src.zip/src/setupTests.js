// setupTests.ts

// 1. Add custom matchers from jest-dom
import '@testing-library/jest-dom';

// 2. Add cleanup to unmount components between tests (already automatic in RTL >13)
import { cleanup } from '@testing-library/react';
import { vi, afterEach } from 'vitest';

afterEach(() => {
    cleanup();
    vi.restoreAllMocks(); // Restore original implementations after each test
    vi.useRealTimers();
});

// 3. Optional: silence console noise for cleaner test output
// especially useful in CI where logs can be overwhelming
beforeAll(() => {
    vi.useFakeTimers(); // Only if you need timers
    vi.spyOn(console, 'warn').mockImplementation(() => { });
    vi.spyOn(console, 'error').mockImplementation(() => { });
});

// 👇 Optional: Mock ResizeObserver (used in many component libs)
global.ResizeObserver = class {
    observe() { }
    unobserve() { }
    disconnect() { }
};

// 👇 Optional: Mock IntersectionObserver
global.IntersectionObserver = class {
    observe() { }
    unobserve() { }
    disconnect() { }
};


// 4. Optional: Mock browser APIs (like localStorage, matchMedia)
Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: (query) => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: vi.fn(),    // deprecated
        removeListener: vi.fn(), // deprecated
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        dispatchEvent: vi.fn(),
    }),
});
