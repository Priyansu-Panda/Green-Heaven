import msgs from '@/messages.json'
import { motion, AnimatePresence } from 'motion/react'
import { useEffect, useState } from 'react';

const AnimatedTextBox = () => {
  const [showCursor, setShowCursor] = useState(false);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const textTimer = setInterval(() => {
      setIndex(v => ((v + 1) % msgs.length))
    }, 10000)

    return () => {
      clearInterval(textTimer)
    }
  }, [])

  return (
    <div data-theme="dark" className="w-fit md:w-100 py-4 overflow-clip bg-base-100/40 backdrop-blur-sm text-base-content  border-primary-content shadow cursor-pointer text-lg px-4 rounded-lg flex text-nowrap font-semibold gap-2">
      <span className="flex items-center justify-center gap-1 w-full">
        <AnimatePresence mode="wait" >
          <motion.div onAnimationComplete={() => setShowCursor(false)} onAnimationStart={() => setShowCursor(true)} className="overflow-clip" key={`msgText_${index}`}
            initial={{ width: 0 }}
            animate={{ width: 'auto' }}
            exit={{ width: 0 }}
            layout
            transition={{ duration: 1 }}>
            {msgs[index]}
          </motion.div>
        </AnimatePresence>
        <span>
          <motion.div layout
            className={`w-[3px] h-8 ${showCursor ? 'bg-white' : ''}`}
            animate={{ opacity: [1, 0, 1] }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        </span>
      </span>
    </div>
  )
}

export default AnimatedTextBox;