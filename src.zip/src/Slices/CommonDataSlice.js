import { createSlice } from '@reduxjs/toolkit'

/**
 * @author Kartik Hatwar
 * @description A slice for common data.
 * 
 * @returns {Object} The common data slice.
 */
const commonDataSlice = createSlice({
  name: 'commonData',
  initialState : {
    theme : {
      name : localStorage.getItem('theme') ? JSON.parse(localStorage.getItem('theme') || JSON.stringify({name : 'light'}))?.name : 'light',
      dark : localStorage.getItem('theme') ? JSON.parse(localStorage.getItem('theme') || JSON.stringify({dark : false}))?.dark : false,
    },
    expand : false,
    heading : "",
    tabs : [],
  },
  reducers: {
/**
     * @description Changes the theme.
     * 
     * @param {Object} state The current state.
     * @param {Object} action The action to change the theme.
     * 
     * @returns {void}
     */
    changeTheme : (state,action)=>{
      state.theme = action.payload;
      localStorage.setItem("theme",JSON.stringify(action.payload));
    },
    /**
     * @description Toggles the expand state.
     * 
     * @param {Object} state The current state.
     * 
     * @returns {void}
     */
    toggleExpand : (state)=>{
        state.expand = !state.expand;
    },
    /**
     * @description Sets the heading.
     * 
     * @param {Object} state The current state.
     * @param {Object} action The action to set the heading.
     * 
     * @returns {void}
     */
    setHeading : (state, action)=>{
      state.heading = action.payload
    },

    setTabs : (state, action)=>{
      state.tabs = action.payload
    },
  },
})

export const { changeTheme, toggleExpand, setHeading , setTabs  } = commonDataSlice.actions

export default commonDataSlice.reducer
