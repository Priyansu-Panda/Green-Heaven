import { useHover, useFocus, useDismiss, useRole, useInteractions, useFloating, offset, flip, shift, autoUpdate, useClick } from '@floating-ui/react';

import { useState } from 'react';

export const ClickTooltip = ({ ToolTipTrigger = "", ToolTipContent = "" }) => {
    const [isOpen, setIsOpen] = useState(false);

    const { refs, floatingStyles, context } = useFloating({
        open: isOpen,
        onOpenChange: setIsOpen,
        middleware: [offset(10), flip(), shift()],
        whileElementsMounted: autoUpdate,
    });

    const click = useClick(context);
    const focus = useFocus(context);
    const dismiss = useDismiss(context);
    const role = useRole(context, { role: 'tooltip' });

    const { getReferenceProps, getFloatingProps } = useInteractions([
        click,
        focus,
        dismiss,
        role,
    ]);

    return (
        <>
            <div ref={refs.setReference} {...getReferenceProps()}>
                {ToolTipTrigger}
            </div>
            {isOpen && (
                <div className='z-90 p-4 packageCard !bg-base-300 text-xs card'
                    ref={refs.setFloating}
                    style={floatingStyles}
                    {...getFloatingProps()}
                >
                    {
                        ToolTipContent
                    }
                </div>
            )}
        </>
    );
}


export const HoverTooltip = ({ ToolTipTrigger = "", ToolTipContent = "" , className="" }) => {
    const [isOpen, setIsOpen] = useState(false);

    const { refs, floatingStyles, context } = useFloating({
        placement : 'right',
        open: isOpen,
        onOpenChange: setIsOpen,
        middleware: [offset(5), flip(), shift()],
        whileElementsMounted: autoUpdate,
    });

    const hover = useHover(context , {move : true});
    const focus = useFocus(context);
    const dismiss = useDismiss(context);
    const role = useRole(context, { role: 'tooltip' });

    const { getReferenceProps, getFloatingProps } = useInteractions([
        hover,
        focus,
        dismiss,
        role,
    ]);

    return (
        <>
            <div ref={refs.setReference} {...getReferenceProps()}>
                {ToolTipTrigger}
            </div>
            {isOpen && (
                <div className={`z-90 p-4 packageCard !bg-base-300 text-xs card ${className}`}
                    ref={refs.setFloating}
                    style={floatingStyles}
                    {...getFloatingProps()}
                >
                    {
                        ToolTipContent
                    }
                </div>
            )}
        </>
    );
}


