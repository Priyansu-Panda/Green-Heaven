import { useEffect, useMemo, useRef, useState } from "react";

const LazyComponentLoader = ({ data = [], itemsPerPage = 99999, loader = null, delay = 300 }) => {
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(false);
    const observerRef = useRef(null);
    const sentinelRef = useRef();
    const loadingRef = useRef(false); // To prevent spamming

    useEffect(() => {
        if (Array.isArray(data) && data.length > 0) {
            setPage(1); // Reset page to 1 when data changes
        }
    }, [data]);

    const visibleItems = useMemo(() => {
        return Array.isArray(data) ? data.slice(0, page * itemsPerPage) : [];
    }, [data, page, itemsPerPage]);

    useEffect(() => {
        if (Array.isArray(data)) {
            setHasMore(data.length > visibleItems.length);
        } else {
            setHasMore(false);
        }
    }, [data, visibleItems.length]);

    useEffect(() => {
        if (!sentinelRef.current || !hasMore) return;

        if (observerRef.current) observerRef.current.disconnect();

        observerRef.current = new IntersectionObserver((entries) => {
            const entry = entries[0];
            if (entry.isIntersecting && !loadingRef.current) {
                loadingRef.current = true;

                // Wait 5 seconds before loading more
                setTimeout(() => {
                    setPage((prev) => prev + 1);
                    loadingRef.current = false;
                }, delay);
            }
        });

        observerRef.current.observe(sentinelRef.current);

        return () => observerRef.current?.disconnect();
    }, [hasMore, visibleItems]);

    return (
        <>
            {visibleItems}
            {/* Sentinel triggers loading */}
            {hasMore && (
                <>
                    <div ref={sentinelRef} className="w-full min-h-[1px]" />
                    {loader}
                </>
            )}
        </>
    );
};

export default LazyComponentLoader;
