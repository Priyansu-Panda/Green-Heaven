import { motion } from 'motion/react'
const AnimatedProfileMenu = ({ username = '', currentRef = null, role = "", firstName = '', lastName = '', email = '', menuList = [], colors = {} }) => {
    const profileWidth = '30rem';

    const userProfileAnimate = {
        initial: {
            width: 0,
            opacity: 0
        },
        animate: {
            opacity: [0, 1, 1],
            width: [0, 0, profileWidth],
            transition: {
                easing: [0.76, 0, 0.24, 1],
                duration: 0.5,
                times: [0, 0.1, 1],
                staggerChildren: 0.05,
                delayChildren: 0.2,
            },
        },
        exit: {
            opacity: [1, 1, 0],
            width: [profileWidth, 0, 0],
            transition: {
                easing: [0.76, 0, 0.24, 1],
                duration: 0.5,
                times: [0, 0.9, 1],
                staggerChildren: 0.05,
            },
        },
    }

    const profileMenuAnimate = {
        initial: { x: -10, opacity: 0 },
        animate: { x: 0, opacity: 1 },
        exit: { x: -10, opacity: 0 },
    }

    return (
        <motion.div variants={userProfileAnimate}
            layout initial="initial" animate="animate" exit="exit" transition="transition"
            key='openProfile' className="absolute border-2 border-base-content/10 rounded-xl origin-bottom-left shadow-xl flex items-end z-10 bottom-1/2 left-[105%] overflow-hidden max-w-fit ">
            <div ref={currentRef} className="w-fit p-4 rounded-xl bg-base-100 overflow-hidden ">
                <motion.div variants={profileMenuAnimate}>
                    <div className="flex flex-nowrap gap-2 items-center py-2 px-2 overflow-clip">
                        <span className={`${colors?.bg} text-white text-lg font-black uppercase rounded-full min-w-[35px] min-h-[35px] flex items-center justify-center`}>
                            {username?.slice(0, 1)}
                        </span>
                        <div className="flex flex-col text-sm overflow-hidden w-full">
                            <span className="font-semibold text-nowrap flex flex-nowrap items-center justify-between gap-2 w-full">{firstName} {lastName}<span className={`font-semibold badge ${colors?.badge} badge-soft badge-xs rounded-lg`}>{role}</span> </span>
                            <span className="opacity-70 text-nowrap text-xs">{email}</span>
                        </div>
                    </div>
                </motion.div>
                <div className="profileMenu">
                    <ul className="flex flex-col w-full px-2">
                        {
                            Array.isArray(menuList) ?
                                menuList?.map((menuItem, i) => <motion.li key={`profileMenu_${i}`} variants={profileMenuAnimate} className={`w-full ${i !== menuList?.length - 1 ? 'border-b' : ''} border-base-content/15 py-2`}>
                                    {menuItem}
                                </motion.li>) :
                                null
                        }
                    </ul>
                </div>
            </div>
        </motion.div>
    )
}

export default AnimatedProfileMenu
