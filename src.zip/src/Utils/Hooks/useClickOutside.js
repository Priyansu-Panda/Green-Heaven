import { useEffect } from 'react';

export function useClickOutside(ref = null, callback = () => { }, ignoreRef = null) {
    useEffect(() => {
        function handleClickOutside(event) {
            if (ref?.current && !ref?.current.contains(event.target)) {
                if (!(ignoreRef?.current && ignoreRef?.current.contains(event.target))) {
                    callback();
                }
            }
        }

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [ref, callback]);
}

