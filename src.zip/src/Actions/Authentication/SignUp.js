import toast from "react-hot-toast";
import { GetRequest, PostRequest } from "../../Utils/RequestHandlers"

export const generateCaptcha = async () => {
    const url = "/api/login/generateCaptcha/";
    const captchaResponse = await GetRequest(url);
    if (captchaResponse.status === 'SUCCESS') return captchaResponse.data;
    else toast.error(captchaResponse.message);
    return null;
}

export const checkDuplicateEmail = async (email) => {
    const url = "/api/login/checkDuplicateEmail/";
    const emailResponse = await PostRequest(url,{email});
    if (emailResponse.status === 'SUCCESS') return false;
    return true;
}

export const registerUser = async (captcha,email,firstName,lastName,password,username) => {
    const url = "/api/login/registerNewUser/";
    const registerResponse = await PostRequest(url,{captcha,email,firstName,lastName,password,username});
    return registerResponse;
}