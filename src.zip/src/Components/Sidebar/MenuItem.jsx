import { FaCaretDown, FaCaretUp } from "react-icons/fa";
import { HoverTooltip } from "../Common/ToolTip";
import { Link, useLocation } from "react-router";
import { useState } from "react";
import { useSelector } from "react-redux";
import { AnimatePresence, motion } from "motion/react";

const MenuItem = ({ item = {} }) => {
    const location = useLocation();
    const [expandChild, setExpandChild] = useState(false);
    const { expand } = useSelector((state) => state.commonData);

    const itemAnimate = {
        hidden: { y: -10, opacity: 0 },
        show: { y: 0, opacity: 1 }
    }

    const expandAnimate = {
        hidden: {
            opacity: 1, height: 0,
            paddingTop: '0',
            paddingBottom: '0',
        },
        show: {
            opacity: 1,
            height: 'auto',
            paddingTop: '0.75rem',
            paddingBottom: '0.75rem',
            transition: {
                delayChildren: 0.1,
                staggerChildren: 0.15
            }
        }
    }

    const expandChildAnimate = {
        hidden: { scale: 0 },
        show: { scale: 1 }
    }

    return (
        item?.child ?

            // Link with Children
            <motion.div variants={itemAnimate} className="menuChild flex flex-col gap-2">
                <div className="w-full">
                    <HoverTooltip
                        ToolTipTrigger={
                            <div onClick={() => setExpandChild(v => !v)}
                                className={`px-[0.8rem] py-[0.375rem] rounded-lg cursor-pointer flex items-center glassMenuItem !gap-0 z-10 border-t-2 border-x-1 duration-200`}
                            >
                                {item?.icon && <item.icon className="text-2xl" />}
                                <span
                                    className={`overflow-hidden text-sm text-nowrap font-medium ${!expand ? "w-0 visibility-none" : "w-30 ml-3"} flex justify-between items-center duration-300`}
                                >
                                    {item?.heading}
                                    {expandChild ? <FaCaretUp /> : <FaCaretDown />}
                                </span>
                            </div>
                        }
                        className="px-3 py-1 !bg-base-100 !rounded-md"
                        ToolTipContent={item?.heading}
                    />
                </div>
                <AnimatePresence mode="wait">
                    {
                        expandChild &&
                        <motion.div variants={expandAnimate} initial="hidden" animate="show" exit="hidden" key={item.heading} className="w-full bg-base-content/4 border-l border-base-content/10 flex flex-col gap-3 overflow-clip rounded-lg">
                            {
                                item.child?.map((subItem) => {
                                    return (
                                        <motion.div variants={expandChildAnimate} key={item.link + subItem.link} className="w-full">
                                            <HoverTooltip
                                                ToolTipTrigger={
                                                    <Link
                                                        to={item.link + subItem.link || '#'}
                                                        className={`px-[0.6rem] py-[0.375rem] mx-1 rounded-lg flex items-center ${location.pathname === item.link + subItem.link ? "selectedGlassMenuItem" : 'glassMenuItem'} !gap-0 z-10 border-t-2 border-x-1 duration-200`}
                                                    >
                                                        {subItem?.icon && <subItem.icon className="text-xl duration-300" />}
                                                        <span
                                                            className={`overflow-hidden text-xs text-nowrap font-medium ${!expand ? "w-0 visibility-none" : "w-28 ml-3"} duration-300`}
                                                        >
                                                            {subItem?.heading}
                                                        </span>
                                                    </Link>
                                                }
                                                className="px-3 py-1 !bg-base-100 !rounded-lg"
                                                ToolTipContent={subItem?.heading}
                                            />
                                        </motion.div>
                                    )
                                })
                            }
                        </motion.div>
                    }
                </AnimatePresence>
            </motion.div> :

            // Normal Link

            <motion.div variants={itemAnimate} className="w-full menuChild">
                <HoverTooltip
                    ToolTipTrigger={
                        <Link
                            to={item?.link || '#'}
                            className={`px-[0.8rem] py-[0.375rem] rounded-lg flex items-center ${location.pathname === item?.link ? "selectedGlassMenuItem" : 'glassMenuItem'} !gap-0 z-10 border-t-2 border-x-1 duration-200`}
                        >
                            {item?.icon && <item.icon className="text-2xl duration-300" />}
                            <span
                                className={`overflow-hidden text-sm text-nowrap font-medium ${!expand ? "w-0 visibility-none" : "w-30 ml-3"}  duration-300`}
                            >
                                {item?.heading}
                            </span>
                        </Link>
                    }
                    className="px-3 py-1 !bg-base-100 !rounded-md"
                    ToolTipContent={item?.heading}
                />
            </motion.div>
    )
}

export default MenuItem;