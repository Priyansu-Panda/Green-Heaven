import axios from "axios"
import toast from "react-hot-toast";

import { getToken, getUser } from "./GetLocalUserData";
const userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

export const GetRequest = async (url, succesMsg = "", errorMsg = "") => {
    try {
        const res = await axios.get(url);
        toast.remove("offline_status")
        if (res.status === 200) {
            if (succesMsg) {
                toast.success(succesMsg || res?.data?.message, { id: url })
            }
            return res.data;
        }
    }
    catch (err) {
        if (err?.code === "ERR_NETWORK") {
            toast.error("You Are Offline", { id: "offline_status" , duration : 3600000 })
        }
        else toast.remove('offline_status')

        if (errorMsg) {
            toast.error(errorMsg, { id: url })
        }
        return err;
    }
}

export const AuthGetRequest = async (url, succesMsg = "", errorMsg = "") => {
    try {
        const token = getToken();
        if (!token) {
            localStorage.removeItem('ROLE_DETAILS');
            localStorage.removeItem('ROLE_PERMISSIONS');
            localStorage.removeItem('TOKEN');
            localStorage.removeItem('USER');
            window.location.reload();
        }

        const config = {
            headers: { 'Authorization': 'Bearer ' + token, userTimeZone: userTimeZone }
        };

        const res = await axios.get(url, config);
        toast.remove("offline_status")
        if (res.status === 200) {
            if (succesMsg) {
                toast.success(succesMsg || res?.data?.message, { id: url })
            }
            return res.data;
        }
    }
    catch (err) {
        if (err?.code === "ERR_NETWORK") {
            toast.error("You Are Offline", { id: "offline_status" , duration : 3600000 })
        }
        else toast.remove('offline_status')

        if (errorMsg) {
            toast.error(errorMsg, { id: url })
        }
        return err;
    }
}

export const PostRequest = async (url, params, succesMsg = "") => {
    try {
        const res = await axios.post(url, params);
        toast.remove("offline_status")
        if (res.status === 200) {
            if (succesMsg) {
                toast.success(succesMsg || res?.data?.message, { id: url })
            }
            return res.data;
        }
    }
    catch (err) {
        if (err?.code === "ERR_NETWORK") {
            toast.error("You Are Offline", { id: "offline_status" , duration : 3600000 })
        }
        else toast.remove('offline_status')

        return err;
    }
}

export const AuthPostRequest = async (url, params = {}, succesMsg = "", errorMsg = "") => {
    try {
        const token = getToken();
        if (!token) {
            localStorage.removeItem('ROLE_DETAILS');
            localStorage.removeItem('ROLE_PERMISSIONS');
            localStorage.removeItem('TOKEN');
            localStorage.removeItem('USER');
            window.location.reload();
        }

        params.loggedInUser = getUser();
        const config = {
            headers: { 'Authorization': 'Bearer ' + token, userTimeZone: userTimeZone }
        };

        const res = await axios.post(url, params, config);
        toast.remove("offline_status")
        if (res.status === 200) {
            if (succesMsg) {
                toast.success(succesMsg, { id: url })
            }
            return res.data;
        }
    }
    catch (err) {
        if (err?.code === "ERR_NETWORK") {
            toast.error("You Are Offline", { id: "offline_status" , duration : 3600000 })
        }
        else toast.remove('offline_status')

        if (err?.status === 401) {
            localStorage.removeItem('ROLE_DETAILS');
            localStorage.removeItem('ROLE_PERMISSIONS');
            localStorage.removeItem('TOKEN');
            localStorage.removeItem('USER');
            window.location.reload();
            toast.error("Session Expired");
            return null;
        }
        if (errorMsg) {
            toast.error(errorMsg, { id: url })
        }
        return err;
    }
}

export const AuthDownloadRequest = async (url, params = {}, succesMsg = "", errorMsg = "") => {
    try {
        const token = getToken();
        if (!token) {
            localStorage.removeItem('ROLE_DETAILS');
            localStorage.removeItem('ROLE_PERMISSIONS');
            localStorage.removeItem('TOKEN');
            localStorage.removeItem('USER');
            window.location.reload();
            toast.error("Session Expired");
            return null;
        }

        const config = {
            headers: { 'Authorization': 'Bearer ' + token, userTimeZone: userTimeZone },
            responseType: 'blob'
        };
        params.loggedInUser = getUser();

        const res = await axios.post(url, params, config);
        toast.remove("offline_status")
        if (res.status === 200) {
            if (succesMsg) {
                toast.success(succesMsg, { id: url })
            }
            return res.data;
        }
    }
    catch (err) {
        if (err?.code === "ERR_NETWORK") {
            toast.error("You Are Offline", { id: "offline_status" , duration : 3600000 })
        }
        else toast.remove('offline_status')

        if (err.status === 401) {
            localStorage.removeItem('ROLE_DETAILS');
            localStorage.removeItem('ROLE_PERMISSIONS');
            localStorage.removeItem('TOKEN');
            localStorage.removeItem('USER');
            window.location.reload();
            toast.error("Session Expired");
            return null;
        }

        if (errorMsg) {
            toast.error(errorMsg, { id: url })
        }
        return null;
    }
}