import { createSlice } from '@reduxjs/toolkit'
import { getRoleInfo, getToken, getUser } from '../Utils/GetLocalUserData'

/**
 * @author Kartik Hatwar
 * @description A slice for user data.
 * 
 * @returns {Object} The user data slice.
 */
const userDataSlice = createSlice({
  name: 'userData',
  initialState: {
    user: getUser(),
    token: getToken(),
    roleDetails: getRoleInfo()?.roleDetails || {},
    rolePermissions: getRoleInfo()?.rolePermissions || [],
    // TODO - Remove after demo
    currentWorkspace: 0,
  },
  reducers: {
    /**
     * @description Updates the user data.
     * 
     * @param {Object} state The current state.
     * @param {Object} action The action to update the user data.
     * 
     * @returns {void}
     */
    updateUserData: (state, action) => {
      if (action.payload.user) localStorage.setItem('USER', JSON.stringify(action.payload.user))
      if (action.payload.token) localStorage.setItem('TOKEN', JSON.stringify(action.payload.token))
      if (action.payload.roleDetails) localStorage.setItem('ROLE_DETAILS', JSON.stringify(action.payload.roleDetails))
      if (action.payload.rolePermissions) localStorage.setItem('ROLE_PERMISSIONS', JSON.stringify(action.payload.rolePermissions))
      if (action.payload.user) state.user = action.payload.user;
      if (action.payload.token) state.token = action.payload.token;
      if (action.payload.roleDetails) state.roleDetails = action.payload.roleDetails;
      if (action.payload.rolePermissions) state.rolePermissions = action.payload.rolePermissions;
    },
    // TODO - Remove after demo
    changeWorkspace: (state, action) => {
      if (action.payload.workspace) {
        state.currentWorkspace = action.payload.workspace;
      }
    },
    /**
     * @description Clears the user data.
     * 
     * @param {Object} state The current state.
     * 
     * @returns {void}
     */
    clearUserData: (state) => {
      localStorage.removeItem('USER');
      localStorage.removeItem('TOKEN');
      localStorage.removeItem('ROLE_DETAILS');
      localStorage.removeItem('ROLE_PERMISSIONS');
      state.token = null;
      state.user = null;
      state.roleDetails = {};
      state.rolePermissons = [];
    },
  },
})

export const { updateUserData, clearUserData, changeWorkspace } = userDataSlice.actions

export default userDataSlice.reducer
