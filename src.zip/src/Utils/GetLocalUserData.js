/**
 * @author Kartik Hatwar
 * @description Gets the token from local storage.
 * 
 * @returns {string|null} The token if it exists, otherwise null.
 */
export const getToken = () => {
    try {
        const token = localStorage.getItem('TOKEN');
        if (token) return JSON.parse(token);
        return null;
    }
    catch {
        return null;
    }
}

/**
 * @description Gets the user from local storage.
 * 
 * @returns {Object|null} The user if it exists, otherwise null.
 */
export const getUser = () => {
    try {
        const user = localStorage.getItem('USER');
        if (user) return JSON.parse(user)
        return null;
    }
    catch {
        return null;
    }
}


export const getRoleInfo = () => {
    let data = { roleDetails: {}, rolePermissions: [] };
    try {
        const roleDetailsStr = localStorage.getItem('ROLE_DETAILS');
        const rolePermissonsStr = localStorage.getItem('ROLE_PERMISSIONS');
        if (roleDetailsStr) data.roleDetails = JSON.parse(roleDetailsStr);
        if (rolePermissonsStr) data.rolePermissions = JSON.parse(rolePermissonsStr);
        return data;
    }
    catch {
        return { roleDetails: {}, rolePermissions: [] };
    }
}