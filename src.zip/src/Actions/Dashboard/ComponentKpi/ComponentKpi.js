import { AuthPostRequest } from "../../../Utils/RequestHandlers";

export const getComponentKPI = async (vehicle_feature, project_model_year) => {
    const url = '/api/db/get_component_kpi';
    const componentKPI = await AuthPostRequest(url, { vehicle_feature, project_model_year });
    if (componentKPI.status === 'SUCCESS') return componentKPI.data;
    else return null;
}