import { DayPicker, getDefaultClassNames } from "react-day-picker";
import "react-day-picker/style.css";


const Calendar = ({ mode = 'single', selected = null, setSelected = () => { } }) => {
    const defaultClassNames = getDefaultClassNames();
    const matcher = {
        from: new Date(),
        to: new Date()
    };
    const defaultSelected = mode === "single" ? new Date() : mode === "range" ? matcher : [new Date()];

    return (
        <div className="flex items-center justify-center h-full">
            <DayPicker
                onSelect={setSelected}
                mode={mode || "single"}
                selected={selected || defaultSelected}
                disabled={{ after: new Date(), before: null }}

                classNames={{
                    range_start: '!bg-primary/30 !rounded-r-none !rounded-l-full ',
                    range_end: '!bg-primary/30 !rounded-l-none !rounded-r-full',
                    range_middle: 'bg-primary/30 text-white !border-none',
                    today: 'bg-base-content/10 rounded-full',
                    selected: 'border-none',
                    root: `${defaultClassNames.root} !w-11/12 !h-11/12`,
                    disabled: `${defaultClassNames.disabled} !cursor-not-allowed`
                }}
            />
        </div>
    );
}

export default Calendar;