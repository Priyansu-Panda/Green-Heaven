import { motion } from "motion/react";

const Tabs = ({ id = "", tab = 0, tabList = [], setTab = () => { } }) => {
  return (
    <motion.div layout className="py-1 px-2 flex gap-4 flex-wrap">
      {
        tabList?.map((tabItem, i) => {
          return (
            <motion.div layout type="button" key={`${id}_${i}_${tabItem?.name}`}  >
              <motion.button onClick={() => setTab(tabItem?.value)} className={`${tabItem?.value === tab ? 'text-primary' : ''} transition-all duration-300 px-3 py-1 cursor-pointer border-t-2 border-x border-transparent hover:border-base-content/7 hover:bg-base-content/5 rounded-lg`}>{tabItem?.name}</motion.button>
              {tabItem?.value === tab && <motion.div layoutId={`layoutborder${id}`} className="w-full h-[2px] rounded-full bg-primary" />}
            </motion.div>
          )
        })
      }
    </motion.div>
  ) 
}

export default Tabs;