import toast from "react-hot-toast";
import { AuthPostRequest, PostRequest } from "../../Utils/RequestHandlers"

export const AuthenticateUser = async (username, password) => {
    const url = "/api/login/authenticate/";
    const userResponse = await PostRequest(url, { username, password }, null, "Login Failed");
    return userResponse;
}

export const LogOutUser = async () => {
    const url = "/api/login/logoutUser/";
    const userResponse = await AuthPostRequest(url, {}, null, "Log Out Failed");
    if (userResponse.status === 'SUCCESS') return true;
    else toast.error("Log Out Failed",{id : "logoutError"});
    return false;
}