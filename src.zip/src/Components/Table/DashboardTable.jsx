import React, { Fragment, useState } from "react";
import { FaCaretDown, FaCaretUp } from "react-icons/fa";
import { GoAlertFill } from "react-icons/go";


const DashboardTable = ({ id = null, isSecondTable = false, data = [], data2 = [], columns = [], columns2 = [], loading = false, noDataMsg = "Data Not Available", noDataMsg2 = "Data Not Available", heading = "" }) => {
    const [expand, setExpand] = useState(true);

    return (
        <div className="overflow-hidden min-h-fit w-full h-fit rounded-2xl bg-base-100 border border-primary/35 shadow-lg">
            <div className="header bg-base-300  px-4 py-2 text-sm flex gap-2 items-center cursor-pointer" onClick={() => setExpand(v => !v)}>
                <span className="text-lg">{expand ? <FaCaretUp /> : <FaCaretDown />}</span>
                {heading}
            </div>
            {
                expand ?
                    <div className="w-full flex flex-col gap-6 h-fit">
                        <div className="w-full overflow-auto">
                            <table className="table table-zebra table-sm w-full h-fit">
                                <thead>
                                    {
                                        ((Array.isArray(data) && data?.length > 0) || loading) ? <tr className="text-[0.875rem]">
                                            {columns?.map((col, i) => <th key={`table_${id}_heading_${i}`} className={`border border-base-content/20 ${i === 0 ? 'border-l-0' : ''} ${i === columns?.length - 1 ? 'border-r-0' : ''} ${col?.colHeadingClass} text-wrap text-center bg-base-200`}>{col?.heading}</th>)}
                                        </tr> : null
                                    }
                                </thead>
                                <tbody className="relative">
                                    {
                                        loading ?
                                            [1, 2, 3, 4].map(v => {
                                                return (
                                                    <tr key={`loading_table_${v}`} className="!text-[0.875rem]">
                                                        {columns?.map((v, i) => <td key={`${v.field}_${i}`} className="w-auto h-4 border-2 border-base-content/20"><div className="skeleton h-4 min-w-11/12" /></td>)}
                                                    </tr>
                                                )
                                            })
                                            :
                                            (Array.isArray(data) && data?.length > 0) ?
                                                data?.map((row, i) => {
                                                    return (<Fragment key={`table_${id}_row_${i}`}>
                                                        <tr className="!text-[0.875rem]">
                                                            {columns?.map((col, j) => {
                                                                const otherFields = col?.otherFields?.map(f => row[f]) || [];
                                                                const className = col?.colDataClass ? col?.colDataClass(row[col?.field], ...otherFields, i) : "";
                                                                return <td key={`table_${id}_row_${i}_col_${j}`} className={`border border-base-content/20 ${j === 0 ? 'border-l-0' : ''} ${j === columns?.length - 1 ? 'border-r-0' : ''} text-center ${className}`}>{col?.field ? col?.formatter ? col?.formatter(row[col?.field], ...otherFields, i) : row[col?.field] : i + 1}</td>
                                                            })}
                                                        </tr>
                                                    </Fragment>)
                                                }) : null
                                    }
                                </tbody>
                            </table>
                        </div>

                        {
                            isSecondTable ?
                                <div className="w-full overflow-auto">
                                    <table className="table table-zebra table-sm w-full h-fit">
                                        <thead>
                                            {
                                                ((Array.isArray(data2) && data2?.length > 0) || loading) ? <tr className="text-[0.875rem]">
                                                    {columns2?.map((col, i) => <th key={`table2_${id}_heading_${i}`} className={`border border-base-content/20 ${i === 0 ? 'border-l-0' : ''} ${i === columns2?.length - 1 ? 'border-r-0' : ''} ${col?.colHeadingClass} text-wrap text-center bg-base-200`}>{col?.heading}</th>)}
                                                </tr> : null
                                            }
                                        </thead>
                                        <tbody className="relative">
                                            {
                                                loading ?
                                                    [1, 2, 3, 4].map(v => {
                                                        return (
                                                            <tr key={`loading_table2_${v}`} className="!text-[0.875rem]">
                                                                {columns2?.map((v, i) => <td key={`${v.field}_${i}`} className="w-auto h-4 border border-base-content/20"><div className="skeleton h-4 min-w-11/12" /></td>)}
                                                            </tr>
                                                        )
                                                    })
                                                    :
                                                    (Array.isArray(data2) && data2?.length > 0) ?
                                                        data2?.map((row, i) => {
                                                            return (<Fragment key={`table2_${id}_row_${i}`}>
                                                                <tr className="!text-[0.875rem]">
                                                                    {columns2?.map((col, j) => {
                                                                        const otherFields = col?.otherFields?.map(f => row[f]) || [];
                                                                        const className = col?.colDataClass ? col?.colDataClass(row[col?.field], ...otherFields, i) : "";
                                                                        return <td key={`table2_${id}_row_${i}_col_${j}`} className={`border border-base-content/20 ${j === 0 ? 'border-l-0' : ''} ${j === columns2?.length - 1 ? 'border-r-0' : ''} text-center ${className}`}>{col?.field ? col?.formatter ? col?.formatter(row[col?.field], ...otherFields, i) : row[col?.field] : i + 1}</td>
                                                                    })}
                                                                </tr>
                                                            </Fragment>)
                                                        }) : null
                                            }
                                        </tbody>
                                    </table>
                                </div>
                                : null
                        }
                        {
                            (!(Array.isArray(data) && data?.length > 0) && !loading) ?
                                <div role="alert" className="alert alert-error alert-outline flex justify-center rounded-t-none rounded-2xl">
                                    <span><GoAlertFill className="text-error text-2xl" /></span><span className="text-error">{noDataMsg}</span>
                                </div> : null
                        }

                        {
                            (!(Array.isArray(data2) && data2?.length > 0) && !loading && isSecondTable) ?
                                <div role="alert" className="alert alert-error alert-outline flex justify-center rounded-t-none rounded-2xl">
                                    <span><GoAlertFill className="text-error text-2xl" /></span><span className="text-error">{noDataMsg2}</span>
                                </div> : null
                        }
                    </div> : null
            }
        </div>
    );
};

export default DashboardTable;