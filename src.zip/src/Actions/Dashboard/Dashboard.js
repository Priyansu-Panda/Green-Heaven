import toast from "react-hot-toast";
import { AuthPostRequest } from "../../Utils/RequestHandlers";

export const getSubfeatureDetails = async (vehicle_feature, project_model_year) => {
    const url = '/api/db/get_subfeature_details';
    const subFeatureDetails = await AuthPostRequest(url, { vehicle_feature, project_model_year });
    if (subFeatureDetails.status === 'SUCCESS') return subFeatureDetails.data;
    else {a
        if (subFeatureDetails.status === 'ERROR') toast.error(subFeatureDetails.message,{id : 'subFeatureError'});
        return null;  
    }
}

export const getBenchStatus = async () => {
    const url = '/api/db/get_bench_status';
    const benchStatus = await AuthPostRequest(url, {});
    if (benchStatus.status === 'SUCCESS') {
        const obj = benchStatus.data;
        const startTime = new Date(obj.cosim_job_start_time);
        const endTime = new Date(obj.cosim_job_end_time);

        const duration = endTime.getTime() - startTime.getTime();

        const hours = Math.floor(duration / (1000 * 60 * 60));
        const minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((duration % (1000 * 60)) / 1000);

        const durationString = `${String(hours).padStart(2, "0")}:${String(
            minutes
        ).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

        return {
            ...obj,
            cosim_job_id: obj.cosim_job_id,
            duration: durationString,
        };
    }
    else return null;
}