// GanttChart.jsx
import React from "react";
import { Gantt, ViewMode } from "gantt-task-react";
import "gantt-task-react/dist/index.css";

const getBarStyles = (progress) => {
  if (progress < 50) return { progressColor: "red" };
  else if (progress >= 90) return { progressColor: "green" };
  else return { progressColor: "orange" };
};
const today = new Date();

const initializeTasks = (data, type) => {


  const getDates = () => {
    const differenceInDays = Math.floor(Math.random() * 35) + 10 + 365;
    const startDays = Math.floor(Math.random() * 60)

    let start = new Date(today.getTime() + startDays * 1000 * 3600 * 24 - 30 * 1000 * 3600 * 24);
    const end = new Date(
      start.getTime() + differenceInDays * 1000 * 3600 * 24
    );
    return { start, end, today }
  }

  if (type === "subFeatures") {
    return data?.map((task, index) => {
      return {
        id: `task-${index + 1}`,
        name: task.subfeature_name,
        start: task?.subfeature_name === 'In Vehicle Infotainment' ? new Date(today.getTime() - 30 * 1000 * 3600 * 24) : getDates().start,
        end: getDates().end,
        progress: 50,
        // parent: index,
        type: "task",
        styles: getBarStyles(50),
      }
    });
  }
  else {
    return data?.map((component, index) => {
      return {
        id: `component-${index + 1}`,
        name: component.displayName || component.componentName ,
        start: component.componentName === 'In Vehicle Infotainment' ? new Date(today.getTime() - 30 * 1000 * 3600 * 24) : getDates().start,
        end: getDates().end,
        progress: component.progress,
        type: "component",
        styles: getBarStyles(component.progress),
      }
    });
  }
};

const GanttChart = ({ data = [], type = 'features', onBarClick = () => { } }) => {

  const tasks = initializeTasks(data, type);


  return (
    <div className="bg-white text-black">
      <Gantt timeStep={10}
        viewDate={today}
        tasks={tasks}
        viewMode={ViewMode.Week}
        onClick={type === 'features' ? e=>onBarClick(e) : null}
        columnWidth={90}
        rowHeight={35}
        todayColor="#8FDB00"
      />
    </div>
  );
};

export default GanttChart;
