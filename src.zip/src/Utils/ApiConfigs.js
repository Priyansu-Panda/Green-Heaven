import { refreshInterval } from "../Contants";

const ApiConfigs = {
    revalidateIfStale: false,
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
    refreshInterval: refreshInterval,
    errorRetryCount : 2,
    revalidateOnReconnect : true,
}

export default ApiConfigs;