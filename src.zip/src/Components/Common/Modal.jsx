/**
 * @author Kartik Hatwar
 * @description A reusable Modal component that can be used to display content in a dialog box.
 * 
 * @returns {JSX.Element} The rendered Modal component.
 */
const Modal = ({ children, id = null, className }) => {
    return (
      <dialog id={id} className="modal">
        <div className={`modal-box ${className} border-x-2 border-base-content/10 shadow`}>
          <form method="dialog">
            <button aria-label={`${id}_modal_close_btn`} className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
          </form>
          {children}
        </div>
        <form method="dialog" className="modal-backdrop">
          <button aria-label={`${id}_modal_close_btn_2`}>close</button>
        </form>
      </dialog>
    );
  };
  
  export default Modal;
  