import {  AuthGetRequest } from "../../../Utils/RequestHandlers";

export const getTreeData = async () => {
    const url = 'https://traceability.kineto.kpit.com/traceability-summaries';
    const treeData = await AuthGetRequest(url);
    return treeData;
}