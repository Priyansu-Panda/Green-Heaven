import { useState } from "react"
import LoginModal from "./LoginModal";
import SignUpModal from "./SignUpModal";
import AnimatedTextBox from "@components/AnimatedComponents/AnimatedTextBox";

const LoginPage = () => {
  const [toggle, setToggle] = useState(true);
  const toggleModal = () => setToggle(v => !v)

  return (
    <div data-theme="light" className="flex flex-wrap  justify-between h-screen w-screen overflow-auto">
      <img alt="loginBackground" className="absolute top-0 left-0 w-full h-full" src="./Images/LoginBG.png" />
      <div className="py-10 sm:py-28 flex  z-[1]">
        <div className="container px-10">
          <AnimatedTextBox/>
        </div>
      </div>
      <div className="flex items-center justify-center">
        {toggle ? <LoginModal toggleModal={toggleModal} /> : <SignUpModal toggleModal={toggleModal} />}
      </div>
    </div>
  )
}




export default LoginPage;