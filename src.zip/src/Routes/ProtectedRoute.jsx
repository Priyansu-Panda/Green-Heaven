import { useEffect, useState } from "react"
import { useSelector } from "react-redux";
import LoginPage from "../Pages/LoginPage/LoginPage";
/**
 * @author Kartik Hatwar
 * @description A ProtectedRoute component that checks if the user is authenticated before rendering the protected component.
 * 
 * @param {JSX.Element} component - The component to be rendered if the user is authenticated.
 * @returns {JSX.Element} The rendered component if the user is authenticated, otherwise the LoginPage component.
 */

const ProtectedRoute = ({ component }) => {
  const { user: uData, token: tData } = useSelector(state => state.userData);
  const [user, setUser] = useState(() => uData);
  const [token, setToken] = useState(() => tData);

  /**
   * @description An effect hook that updates the local user and token state with the latest data from the Redux store.
   */

  useEffect(() => {
    setUser(uData);
    setToken(tData);
  }, [uData, tData])

  return ((user && token) ? component : <LoginPage />)
}


export default ProtectedRoute;
