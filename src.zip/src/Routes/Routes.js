import { FaColumns } from "react-icons/fa";


// Modules for Routing 
import Dashboard from "../Pages/Dashboard/Dashboard.jsx";

// Routes with name , path and element
// NOTE - The name is used for permission checking
export const routes = [
    { name: 'DASHBOARD', path: '/', element: Dashboard },
];

// NOTE - The Menu for Side Bar
export const Menu = [
    {
        name: 'DASHBOARD',
        heading: 'Dashboard',
        icon: FaColumns,
        link: '/'
    },
];