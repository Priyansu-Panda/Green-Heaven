export const formatModulePermissions = (moduleList, permissions) => {
    return moduleList?.reduce((acc, module) => {
        const modulePermission = permissions.find(p => p.moduleId === module.moduleId && p.subMdlId === 0);
        const permissionString = modulePermission ? modulePermission.permission : "001";

        const subModules = module.sub_modules.reduce((subAcc, subModule) => {
            const subModulePermission = permissions.find(p => p.moduleId === module.moduleId && p.subMdlId === subModule.subMdlId);
            const subPermissionString = subModulePermission ? subModulePermission.permission : "001";

            subAcc[subModule.subMdlId] = {
                moduleId: module.moduleId,
                subMdlName: subModule.subMdlName,
                update: subPermissionString[0] === "1",
                read: subPermissionString[1] === "1",
                none: subPermissionString[2] === "1",
            };
            return subAcc;
        }, {});

        acc[module.moduleId] = {
            name: module.moduleName,
            update: permissionString[0] === "1",
            read: permissionString[1] === "1",
            none: permissionString[2] === "1",
            sub_modules: subModules,
        };
        return acc;
    }, {});
};

export const formatPackagePermissions = (packageList, permissions) => {
    return packageList.reduce((acc, pkg) => {
        const packagePermission = permissions.find(p => p.id === pkg.id);
        const permissionString = packagePermission ? packagePermission.permission : "001";

        acc[pkg.id] = {
            name: pkg.cosimPkgName,
            update: permissionString[0] === "1",
            read: permissionString[1] === "1",
            none: permissionString[2] === "1",
        };
        return acc;
    }, {});
};

export const formatWorkspacePermissions = (workspaceList, permissions) => {
    return workspaceList?.reduce((acc, wks) => {
        const workspacePermission = permissions.find(w => w.workspaceId === wks.workspaceId);
        const enable = workspacePermission ? workspacePermission.permission : false;

        acc[wks.workspaceId] = {
            ...wks,
            enable: enable
        };
        return acc;
    }, {});
};

const transformArrayToObject = (array) => {
    const result = {};
    array.forEach(item => {
        const { component_name, ...rest } = item;
        result[component_name] = rest;
    });
    return result;
}

export const componentKPIDataFormatter = (data, task, skipMockData = false) => {
    let darray = data || [];
    if (!darray?.length) return [];


    if (!skipMockData) {
        darray[0] = { ...darray?.[0], "component_link": darray?.[0]?.component_name === "TrkDoorCtrl" ? 'https://katapult.kpit.com/enterprise_module_detail_dashboard/Mjk1OA==/bWFpbg==' : null };
        let tdata = [1, 2, 3].map(() => {
            return {
                "component_name": `Component-${Math.floor(Math.random() * 100)}`,
                "component_link": null,
                "branch_name": `Branch-${Math.floor(Math.random() * 100)}`,
                "commit": {
                    "commit_id": `3bb${Math.floor(Math.random() * 100000)}`,
                    "scm_type": Math.random() < 0.5 ? "github" : "gitlab",
                    "commit_link": `https://example.com/commit-${Math.floor(Math.random() * 100000)}`
                },
                "pipeline_id": `PIPELINE-${Math.floor(Math.random() * 100)}`,
                "lines_of_code": Math.floor(Math.random() * 100000),
                "percent_comments": Math.floor(Math.random() * 100),
                "percent_duplication": Math.floor(Math.random() * 100),
                "code_violation": "No Build Available",
                "max_complexity": Math.floor(Math.random() * 100),
                "percent_functions_above_threshold": Math.floor(Math.random() * 100),
                "ut_pass_percentage": Math.floor(Math.random() * 100),
                "code_coverage": Math.floor(Math.random() * 100),
                "sw_test_pass_percentage": Math.floor(Math.random() * 100),
                "requirements_covered": Math.floor(Math.random() * 100)
            }
        });
        darray = [...darray, ...tdata];
    }

    const tableData = transformArrayToObject(darray);

    return Object.keys(tableData).map((key, index) => {
        const rowData = tableData[key];
        return {
            componentName: skipMockData ? key : task?.sub_tasks?.[index]?.sub_task_name,
            component_link: rowData?.["component_link"],
            deploymentTarget: skipMockData ? 'N/A' : task?.sub_tasks?.[index]?.metrics.deployment_target,
            commitNumber: rowData.commit?.["commit_id"],
            commentsPercentage: rowData["percent_comments"],
            lineOfCode: rowData["lines_of_code"],
            codeDuplication: rowData["percent_duplication"],
            codeViolation: rowData["code_violation"],
            maxCodeComplexity: rowData["max_complexity"],
            functionAboveThreshold: rowData["percent_functions_above_threshold"],
            utsPass: rowData["ut_pass_percentage"],
            codeCoverage: rowData["code_coverage"],
            softwareTestPass: rowData["sw_test_pass_percentage"],
            requirementCoverage: rowData["requirements_covered"]
        };
    });

}
