import { Fragment, useEffect, useState } from "react";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { GoAlertFill } from "react-icons/go";


const Table = ({ isFixed = false, level = 2, defaultOpenRow = -1, id = "", columns = [], data = [], loading = false, rowCount = null, noDataMsg = "Data Not Available", expandRow = null, pagination = { rowsPerPage: 0, filtering: false, page: 1, setPage: () => { } }, className = "", tableClassName = "" }) => {
    const count = rowCount || data?.length || 0;
    const [isExpanded, setIsExpanded] = useState(defaultOpenRow);

    const toggleExpand = (index, row) => {
        if (isExpanded === index + (pagination?.page - 1) * (pagination?.rowsPerPage || 0)) setIsExpanded(-1);
        else setIsExpanded(index + (pagination?.page - 1) * (pagination?.rowsPerPage || 0));

        if (expandRow?.onExpand) {
            expandRow?.onExpand(row, isExpanded === -1, index + (pagination?.page - 1) * (pagination?.rowsPerPage || 0))
        }
    }
    // Reset the expanded row when the data or pagination changes
    useEffect(() => {
        if (defaultOpenRow !== -1) setIsExpanded(defaultOpenRow)
    }, [pagination.page, data]);

    useEffect(() => {
        if (data && data?.length > 0) {
            pagination.setPage(Math.min(pagination.page, Math.ceil(count / pagination.rowsPerPage)))
        }
    }, [data])

    return (
        <div className={`h-full w-full p-2 relative flex flex-col justify-between ` + className}>
            <div className={`overflow-x-auto rounded-box border-t-2 border-x border-base-content/15 shadow bg-base-100`}>
                <table className={`table ${isFixed ? 'table-fixed' : ''} ${tableClassName}`}>
                    <thead style={{ zIndex: level }} className={`sticky top-0 bg-base-100`}>
                        {
                            ((Array.isArray(data) && data?.length > 0) || loading) ? <tr className="bg-base-content/2">
                                {expandRow && <th className="w-12"></th>}
                                {columns?.map((col, i) => <th className={`${col?.className}`} key={`table_${id}_heading_${i}`}>{col?.heading}</th>)}
                            </tr> : null
                        }
                    </thead>
                    <tbody className="relative" >
                        {
                            loading ?
                                [1, 2, 3, 4].map(v => {
                                    return (
                                        <tr key={`loading_table_${v}`}>
                                            {expandRow && <td className="w-auto h-4"><div className="skeleton h-4 min-w-11/12" /></td>}
                                            {columns?.map((v, i) => <td key={`${v.field}_${i}`} className="w-auto h-4"><div className="skeleton h-4 min-w-11/12" /></td>)}
                                        </tr>
                                    )
                                })
                                :
                                (Array.isArray(data) && data?.length > 0) ?
                                    data?.filter((v, i) => {
                                        return ((pagination?.page - 1) * pagination?.rowsPerPage <= i && i < (pagination?.page) * pagination?.rowsPerPage || !pagination.filtering)
                                    })?.map((row, i) => {
                                        return (<Fragment key={`table_${id}_row_${i}`}>
                                            <tr>
                                                {expandRow && <th className="!w-12">{isExpanded === (i + (pagination?.page - 1) * (pagination?.rowsPerPage || 0)) ? <FaChevronUp onClick={() => toggleExpand(i, row)} className="cursor-pointer opacity-60 hover:opacity-100" /> : <FaChevronDown onClick={() => toggleExpand(i, row)} className="cursor-pointer opacity-60 hover:opacity-100" />}</th>}
                                                {columns?.map((col, j) => {
                                                    const otherFields = col?.otherFields?.map(f => row[f]) || [];
                                                    return <td key={`table_${id}_row_${i}_col_${j}`}>{col?.field ? col?.formatter ? col?.formatter(row[col?.field], ...otherFields, i) : row[col?.field] : i + 1}</td>
                                                })}
                                            </tr>
                                            {
                                                isExpanded === (i + (pagination?.page - 1) * (pagination?.rowsPerPage || 0)) && expandRow?.renderer ?
                                                    <tr>
                                                        <td className="bg-base-300" colSpan={8} align="center">
                                                            {expandRow?.renderer(row)}
                                                        </td>
                                                    </tr> :
                                                    null
                                            }

                                        </Fragment>)
                                    }) : null
                        }

                    </tbody>
                </table>
                {/* No Data Message  */}
                {
                    (!(Array.isArray(data) && data?.length > 0) && !loading) ?
                        <div role="alert" className="alert alert-error alert-outline flex justify-center">
                            <span><GoAlertFill className="text-error text-2xl" /></span><span className="text-error">{noDataMsg}</span>
                        </div> : null
                }
            </div>

            {pagination.rowsPerPage ? <div className="ml-auto mt-2 mr-6">
                <Pagination page={pagination?.page} setPage={pagination?.setPage} count={count} rowsPerPage={pagination?.rowsPerPage} />
            </div> : null}

        </div>
    )
}

export default Table;

const Pagination = ({ page, setPage, count, rowsPerPage }) => {
    const totalPages = Math.ceil(count / rowsPerPage);

    return (
        totalPages === 1 ? null :
            totalPages <= 10 ?
                <div className="join shadow-lg border border-base-content/25 rounded-lg">
                    {new Array(totalPages).fill(0).map((v, i) => {
                        return <button type="button" key={`p_${i}`} onClick={() => setPage(i + 1)} className={`join-item btn ${page === i + 1 ? 'btn-primary' : ''}`}>{i + 1}</button>
                    })}
                </div> :

                <div className="join shadow-lg border border-base-content/25 rounded-lg">
                    <button type="button" onClick={() => setPage(Math.max(page - 10, 1))} disabled={page === 1} className="join-item btn">«</button>
                    {page > 2 && <button type="button" onClick={() => setPage(1)} className="join-item btn">1</button>}
                    {page > 3 && <button type="button" className="join-item btn btn-disabled">...</button>}
                    {page > 1 && <button type="button" onClick={() => setPage(page - 1)} className="join-item btn">{page - 1}</button>}
                    <button type="button" className="join-item btn btn-primary">{page}</button>
                    {page + 1 < totalPages && <button type="button" onClick={() => setPage(page + 1)} className="join-item btn">{page + 1}</button>}
                    {page + 2 < totalPages && <button type="button" className="join-item btn btn-disabled">...</button>}
                    {page < totalPages && <button type="button" onClick={() => setPage(totalPages)} className="join-item btn">{totalPages}</button>}
                    <button type="button" disabled={page === totalPages} onClick={() => setPage(Math.min(page + 10, totalPages))} className="join-item btn">»</button>
                </div>

    );

};




