// import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { BrowserRouter } from 'react-router'
import { Provider } from 'react-redux'
import store from './store.js'
import { Toaster } from 'react-hot-toast'
import { registerSW } from 'virtual:pwa-register'

registerSW({ immediate: true });

createRoot(document.getElementById('root')).render(
  // <StrictMode> //NOTE - Enable in Development
  <BrowserRouter>
    <Provider store={store}>
      <Toaster />
      <App />
    </Provider>
  </BrowserRouter>
  // </StrictMode>,
)
