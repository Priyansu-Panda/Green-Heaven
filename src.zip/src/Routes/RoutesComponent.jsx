import { Navigate, Route, Routes } from "react-router";
import { useSelector } from "react-redux";
import { routes } from "./Routes.js";
import Navbar from "../Components/NavBar/NavBar.jsx";
import Sidebar from "../Components/Sidebar/Sidebar.jsx";
import { formatData } from "../Utils/ModuleDataFormatter.js";
import { useMemo } from "react";

// TODO - Remove after demo

/**
 * @author Kartik Hatwar
 * @description A component that defines the routes for the application.
 * 
 * @returns {JSX.Element} The routes component.
*/
const RoutesComponent = () => {
  /**
   * @description Gets the current theme from the Redux state.
  */
 const { theme } = useSelector((state) => state.commonData);
 const { roleDetails, rolePermissions } = useSelector((state) => state.userData);

  /**
   * @description Checks if the user has admin privileges.
   */
  const isAdmin = roleDetails?.role?.name === "Admin";

  const permissions = useMemo(() => formatData(rolePermissions), [rolePermissions]);

  /**
   * @description Filters routes based on user permissions.
   */
  const filteredRoutes = useMemo(() => {
    return routes.filter((route) => {
      if (isAdmin) return true; // Allow all routes for admin
      const permissionKey = route.name === 'TEST_EXECUTION' ? permissions['HOME'] : permissions[route.name];
      if (permissionKey?.permissions) {
        const [update, read] = permissionKey.permissions.split("").map(Number); // Split "110" into [1, 1, 0]
        if (update === 1 || read === 1) return true; // Allow route if update or read is 1
        return false; // Exclude route
      }
      return false; // Exclude route if no permissions or none are allowed
    });
  }, [routes, permissions, isAdmin]);


  return (
    <div data-theme={theme.name} className="h-screen flex flex-col">
      <Navbar />
      <div className="flex grow-1 min-h-[92dvh]">
        <Sidebar/>
        <div className="grow-1 !h-[92dvh] overflow-y-auto p-2 bg-base-300">
          <Routes>
            {filteredRoutes.map((route) => (
              <Route
                key={route.path}
                path={route.path}
                index={route.path === "/"}
                element={<route.element />}
              />
            ))}
            <Route path="*" element={<Navigate to={'/'} />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default RoutesComponent;
