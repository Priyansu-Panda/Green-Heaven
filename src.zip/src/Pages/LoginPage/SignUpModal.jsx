import { useState } from "react";
import { IoMdRefresh } from "react-icons/io";
import ApiConfigs from "../../Utils/ApiConfigs";
import { checkDuplicateEmail, generateCaptcha, registerUser } from "../../Actions/Authentication/SignUp";
import useSWR from 'swr'
import toast from "react-hot-toast";
import { useSelector } from "react-redux";

const SignUpModal = ({ toggleModal }) => {
    const { data: captchaStr, isLoading, mutate } = useSWR('captcha', generateCaptcha, { ...ApiConfigs, refreshInterval: 0, dedupingInterval: 0, revalidateOnMount: true });

    const { theme } = useSelector((state) => state.commonData);

    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [cpassword, setCpassword] = useState("");
    const [captcha, setCaptcha] = useState("");

    const [step, setStep] = useState(0);
    const totalSteps = 2;

    const backUpCaptcha = "x9K6fg"
    const finalCapthcha = captchaStr || backUpCaptcha;

    const handleFirstName = (e) => setFirstName(e.target.value);
    const handleLastName = (e) => setLastName(e.target.value);
    const handleEmail = (e) => setEmail(e.target.value);
    const handlePassword = (e) => setPassword(e.target.value);
    const handleCpassword = (e) => setCpassword(e.target.value);
    const handleCaptcha = (e) => setCaptcha(e.target.value);

    const onSubmit = async (e) => {
        e.preventDefault();

        if (step === 0) {
            const isDuplicate = await checkDuplicateEmail(email)
            if (isDuplicate) { toast.error("Email Already Signed Up", { id: 'error' }); return; }
        }

        if (step === 1) {
            if (captcha !== finalCapthcha) { toast.error("Invalid Captcha", { id: 'error' }); return; }
            if (password !== cpassword) { toast.error("Passwords Not Matching", { id: 'error' }); return; }
        }

        if (step !== totalSteps - 1) { setStep(v => Math.min(totalSteps - 1, v + 1)); return; }

        if (firstName, lastName, email, password, cpassword, captcha) {
            toast.promise(registerUser(captcha, email, firstName, lastName, password, email), {
                success: (data) => {
                    if (data.status === "SUCCESS") {
                        const username = email.substring(0, email.indexOf("@"));
                        localStorage.setItem("prevUser", username);
                        toggleModal();
                        return data?.message || "User Registered";
                    }
                    else toast.error(data?.message || "Failed To Registered")
                },
                loading: "Registering User",
                error: "Failed To Sign Up"
            })
        }
    }

    return (
        <form data-theme="light" onSubmit={onSubmit} className="flex flex-col justify-start gap-8 items-center rounded-2xl bg-gradient-to-tr to-info/10 from-primary/7 bg-base-content/20 backdrop-blur-md min-h-105 min-w-80 border-t-2 border-x border-base-content/20 shadow sm:mr-32 mt-20 ml-32 px-4 py-1">
            <div className="w-full flex flex-col">
                <div className="heading">
                    <h5 className="text-xl font-[600] text-white text-center">Sign Up</h5>
                    <span className="w-7 h-0.75 mx-auto my-2.5 float-none block bg-green-400" />
                </div>
                <div className="flex grow gap-2 flex-col justify-start items-end">

                    {step === 0 ?
                        <div className="w-full flex flex-col gap-1">
                            <div className="w-full">
                                <input value={firstName} onChange={handleFirstName} className="input h-12 bg-base-100/70 validator focus-within:outline-none" type="text" required placeholder="First Name" />
                                <div className="validator-hint">First Name Required</div>
                            </div>

                            <div className="w-full">
                                <input value={lastName} onChange={handleLastName} className="input h-12 bg-base-100/70 validator focus-within:outline-none" type="text" required placeholder="Last Name" />
                                <div className="validator-hint">Last Name Requried</div>
                            </div>

                            <div className="w-full">
                                <input value={email} onChange={handleEmail} className="input h-12 bg-base-100/70 validator focus-within:outline-none" type="email" required placeholder="Email Id" />
                                <div className="validator-hint">Email Requried</div>
                            </div>
                        </div> :
                        <div className="w-full flex flex-col gap-3">
                            <div className="w-full">
                                <input value={password} minLength={5} maxLength={20} onChange={handlePassword} className="input h-12 bg-base-100/70 validator focus-within:outline-none" type="password" required placeholder="Password" />
                                <div className="validator-hint">Password Requried (Atleast 5 Characters)</div>
                            </div>

                            <div className="w-full">
                                <input value={cpassword} minLength={5} maxLength={20} onChange={handleCpassword} className="input h-12 bg-base-100/70 validator focus-within:outline-none" type="password" required placeholder="Confirm Password" />
                                <div className="validator-hint">Confirm Password Requried</div>
                            </div>

                            <div className="w-full flex items-start gap-2">
                                {
                                    isLoading ?
                                        <div className="skeleton min-h-10 basis-1/2" /> :
                                        <div className="rounded-lg bg-base-300 min-h-10 basis-1/2 flex items-center justify-center gap-2">
                                            {
                                                finalCapthcha?.split("")?.map((letter, i) => {
                                                    return <span key={`captcha_${i}`} className="text-xl text-primary captchaCode">{letter}</span>
                                                })
                                            }
                                        </div>
                                }
                                <button type="button" onClick={() => mutate()} className="h-10 flex items-center"><IoMdRefresh className="text-lg cursor-pointer" /></button>
                                <div className="basis-1/2">
                                    <input value={captcha} onChange={handleCaptcha} className="input w-32 validator focus-within:outline-none" type="text" required placeholder="Enter Captcha" />
                                    <div className="validator-hint">Captcha Requried</div>
                                </div>
                            </div>
                        </div>
                    }
                </div>

                <div className="buttons w-full flex gap-4">
                    {
                        step === totalSteps - 1 ?
                            <>
                                {
                                    step !== 0 &&
                                    <button type="button" onClick={() => setStep(v => Math.max(v - 1, 0))} className="btn btn-neutral btn-soft rounded-md mt-auto text-lg  text-base-900 grow">
                                        Back
                                    </button>
                                }
                                <button type="submit" className="btn btn-primary btn-soft rounded-md mt-auto text-lg grow text-base-900">
                                    Sign Up
                                </button>
                            </> :
                            <>
                                {
                                    step !== 0 &&
                                    <button type="button" onClick={() => setStep(v => Math.max(v - 1, 0))} className="btn btn-neutral btn-soft rounded-md mt-4 text-lg text-base-900 grow">
                                        Back
                                    </button>
                                }
                                <button type="submit" className="btn btn-neutral btn-soft rounded-md mt-4 text-lg text-base-900 grow">
                                    Next
                                </button>
                            </>
                    }
                </div>

                <div className="flex flex-col text-sm font-semibold mt-3 gap-1 justify-center">
                    <span className="text-center text-white">Already have an Account ?</span>
                    <button onClick={() => toggleModal()} className="text-primary cursor-pointer hover:text-primary">Login</button>
                </div>

            </div>
        </form>

    )

    return (
        <div data-theme={theme.name} className="bg-base-100/70 backdrop-blur-sm border-t-2 border-x border-base-content/10 card shadow-lg w-[320px] z-10 mx-4 sm:mr-32 mt-16 py-2 flex flex-col gap-16 justify-center">
            <form
                onSubmit={onSubmit}
                className="px-3 py-1 min-h-[55vh] flex flex-col"
            >
                <div className="heading basis-1/8">
                    <h5 className="text-xl font-[600] text-center">Sign Up</h5>
                    <span className="w-7 h-0.75 mx-auto my-2.5 float-none block bg-green-400" />
                </div>

                <div className="flex gap-2 grow flex-col justify-between items-end">

                    {step === 0 ?
                        <div className="w-full flex flex-col gap-1">
                            <div className="w-full">
                                <input value={firstName} onChange={handleFirstName} className="input validator focus-within:outline-none" type="text" required placeholder="First Name" />
                                <div className="validator-hint">First Name Required</div>
                            </div>

                            <div className="w-full">
                                <input value={lastName} onChange={handleLastName} className="input validator focus-within:outline-none" type="text" required placeholder="Last Name" />
                                <div className="validator-hint">Last Name Requried</div>
                            </div>

                            <div className="w-full">
                                <input value={email} onChange={handleEmail} className="input validator focus-within:outline-none" type="email" required placeholder="Email Id" />
                                <div className="validator-hint">Email Requried</div>
                            </div>
                        </div> :
                        <div className="w-full flex flex-col gap-3">
                            <div className="w-full">
                                <input value={password} minLength={5} maxLength={20} onChange={handlePassword} className="input validator focus-within:outline-none" type="password" required placeholder="Password" />
                                <div className="validator-hint">Password Requried (Atleast 5 Characters)</div>
                            </div>

                            <div className="w-full">
                                <input value={cpassword} minLength={5} maxLength={20} onChange={handleCpassword} className="input validator focus-within:outline-none" type="password" required placeholder="Confirm Password" />
                                <div className="validator-hint">Confirm Password Requried</div>
                            </div>

                            <div className="w-full flex items-start gap-2">
                                {
                                    isLoading ?
                                        <div className="skeleton min-h-10 basis-1/2" /> :
                                        <div className="rounded-lg bg-base-300 min-h-10 basis-1/2 flex items-center justify-center gap-2">
                                            {
                                                finalCapthcha?.split("")?.map((letter, i) => {
                                                    return <span key={`captcha_${i}`} className="text-xl text-primary captchaCode">{letter}</span>
                                                })
                                            }
                                        </div>
                                }
                                <button type="button" onClick={() => mutate()} className="h-10 flex items-center"><IoMdRefresh className="text-lg cursor-pointer" /></button>
                                <div className="basis-1/2">
                                    <input value={captcha} onChange={handleCaptcha} className="input validator focus-within:outline-none" type="text" required placeholder="Enter Captcha" />
                                    <div className="validator-hint">Captcha Requried</div>
                                </div>
                            </div>
                        </div>
                    }

                    <div className="buttons w-full flex gap-4">
                        {
                            step === totalSteps - 1 ?
                                <>
                                    {
                                        step !== 0 &&
                                        <button type="button" onClick={() => setStep(v => Math.max(v - 1, 0))} className="btn btn-ghost btn-soft rounded-md mt-auto text-lg  text-base-900 grow">
                                            Back
                                        </button>
                                    }
                                    <button type="submit" className="btn btn-primary btn-soft rounded-md mt-auto text-lg grow text-base-900">
                                        Sign Up
                                    </button>
                                </> :
                                <>
                                    {
                                        step !== 0 &&
                                        <button type="button" onClick={() => setStep(v => Math.max(v - 1, 0))} className="btn btn-neutral btn-soft rounded-md mt-4 text-lg text-base-900 grow">
                                            Back
                                        </button>
                                    }
                                    <button type="submit" className="btn btn-ghost btn-soft rounded-md mt-4 text-lg text-base-900 grow">
                                        Next
                                    </button>
                                </>
                        }
                    </div>

                </div>

                <div className="flex flex-col mt-3 gap-1 justify-center">
                    <span className="text-center">Already have an Account ?</span>
                    <button onClick={() => toggleModal()} className="text-primary font-semibold cursor-pointer hover:text-primary">Login</button>
                </div>
            </form>
        </div>
    )
}

export default SignUpModal;