import { useDispatch } from "react-redux";
import ProtectedRoute from "./Routes/ProtectedRoute.jsx"
import { changeTheme } from "./Slices/CommonDataSlice.js";
import { useEffect } from "react";
import RoutesComponent from "./Routes/RoutesComponent.jsx";
import "./App.css";
import { getRoleInfo, getToken, getUser } from "./Utils/GetLocalUserData.js";
import { updateUserData } from "./Slices/UserDataSlice.js";

function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    const user = getUser();
    const token = getToken();
    const { roleDetails, rolePermissions } = getRoleInfo();
    if (user && token && roleDetails && rolePermissions) {
      dispatch(updateUserData({ user, token, roleDetails, rolePermissions }));
    }
    const themeStr = localStorage.getItem("theme");

    if (themeStr) {
      const theme = JSON.parse(themeStr);
      dispatch(changeTheme(theme))
    }
    else {
      if (window && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        dispatch(changeTheme({ name: 'dark', dark: true }));
      }
      else {
        dispatch(changeTheme({ name: 'light', dark: false }));
      }
    }
  }, [dispatch])

  return (<ProtectedRoute component={<RoutesComponent />} />)
}


export default App
