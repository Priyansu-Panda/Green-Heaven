import React, { useState } from "react";
import { FaChevronRight, FaChevronDown } from "react-icons/fa";

const TreeStucture = ({ treeNodes = [], isLoading = false }) => {
    const [openSuites, setOpenSuites] = useState({});

    const toggleNode = (id, onClickFn) => {
        setOpenSuites((prev) => ({ ...prev, [id]: !prev[id] }));
        if (onClickFn) onClickFn(id);
    };

    return (
        <div className="w-full bg-base-100 rounded-lg px-2 py-4 text-left flex flex-col gap-1">
            {
                isLoading ?
                    <div className="loa">Loading...</div> :
                    Array.isArray(treeNodes) ?
                        treeNodes?.map((treeNode) => (
                            <div key={`treeNode_${treeNode?.id + treeNode?.name}`} className="mb-2">
                                <div
                                    className="flex gap-2 items-center cursor-pointer hover:bg-base-300 px-2 py-1 rounded-md transition"
                                    onClick={() => toggleNode(treeNode?.id, treeNode?.onClick)}
                                >
                                    <div className="min-h-full flex items-center">
                                        {openSuites[treeNode.id] ? (
                                            <FaChevronDown className="text-xs" />
                                        ) : (
                                            <FaChevronRight className="text-xs" />
                                        )}
                                    </div>
                                    <div className="font-bold h-full">{treeNode?.name}</div>
                                </div>

                                {(openSuites?.[treeNode.id])  && (
                                    <div className="ml-6 mt-1 px-2 border-l border-base-content/20 flex flex-col gap-2">
                                        {treeNode?.subNodes?.map((subNode) => (
                                            <div
                                                key={`subNode_${treeNode?.id}_${subNode?.id}_${subNode?.name}`} onClick={() => subNode?.onClick ? subNode?.onClick(subNode?.id) : null}
                                                className="pl-4 py-1 hover:bg-base-300 rounded-md cursor-pointer transition"
                                            >
                                                <span className="text-xs font-semibold text-base-content/75">
                                                    {subNode?.name}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )) :
                        <div className="">Please Provide Tree Structure Proper Sturcture</div>
            }
        </div>
    );
};

export default TreeStucture;
