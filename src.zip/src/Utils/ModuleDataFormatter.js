export const formatData = (data) => {
    let formattedData = {};
    data?.forEach((item) => {
        if (item?.module) {
            if (formattedData[item?.module?.refName]) {
                formattedData[item?.module?.refName] = {
                    ...formattedData?.[item?.module?.refName],
                    subModule: item?.subModule?.refName ? [
                        ...formattedData?.[item?.module?.refName]?.subModule,
                        item?.subModule?.refName,
                    ] : formattedData?.[item?.module?.refName]?.subModule,
                };
            }
            else {
                formattedData[item?.module?.refName] = {
                    permissions: item?.permission || "001",
                    subModule: item?.subModule?.refName ? [item?.subModule?.refName] : [],
                };
            }
        }
    });
    return formattedData;
}

