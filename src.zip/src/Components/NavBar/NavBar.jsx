import { useSelector, useDispatch } from "react-redux";
import { toggleExpand } from "../../Slices/CommonDataSlice";
import { motion, AnimatePresence } from 'motion/react'

/**
 * @author Kartik Hatwar
 * @description A reusable Navbar component that displays a heading and a toggle button to expand or collapse the sidebar.
 *
 * @returns {JSX.Element} The rendered Navbar component.
 */
const Navbar = () => {
  const { heading, expand } = useSelector((state) => state.commonData);
  // const { user } = useSelector((state) => state.userData);

  const dispatch = useDispatch();

  /**
   * @description A function to handle the toggle button click event.
   * It dispatches the toggleExpand action to update the expand state in the Redux store.
   */
  const onChangeExpand = () => {
    dispatch(toggleExpand());
  };

  const animateHeading = {
    hidden: { y: -10, opacity: 0, duration: 1 },
    show: { y: 0, opacity: 1, duration: 1 },
    exit: { y: 10, opacity: 0, duration: 1 }
  }


  return (
    <div className={`navbar !min-h-fit h-fit min-w-fit sm:!min-h-[2rem] sm:!h-[8dvh] bg-secondary`}>
      <div className="flex flex-1 gap-4 items-center">
        <div className="flex-none">
          <label aria-label="toggleMenu" htmlFor="toggleMenu"
            className={`bg-secondary border-none shadow-none text-base-content swap swap-rotate`}
          >
            <input id="toggleMenu"
              aria-labelledby="toggleMenu"
              type="checkbox"
              checked={expand}
              onChange={() => onChangeExpand()}
            />
            <svg className={`swap-off fill-current text-base-content`} xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 512 512" >
              <path d="M64,384H448V341.33H64Zm0-106.67H448V234.67H64ZM64,128v42.67H448V128Z" />
            </svg>
            <svg className={`swap-on fill-current text-base-content`} xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 512 512" >
              <polygon points="400 145.49 366.51 112 256 222.51 145.49 112 112 145.49 222.51 256 112 366.51 145.49 400 256 289.49 366.51 400 400 366.51 289.49 256 400 145.49" />
            </svg>
          </label>
        </div>
        <div className="flex items-center gap-2">
          <h1 className="text-base-content text-md sm:text-2xl font-black mr-6">
            Kineto Roadmap
          </h1>
          <AnimatePresence mode="wait">
            <motion.h1 variants={animateHeading} initial="hidden" animate="show" exit="exit" key={`header_${heading}`} className={`bg-base-content/10  border-base-content/15  ${heading ? 'flex' : 'hidden'} px-3 rounded-md font-semibold text-base-content text-sm sm:text-lg`}>{heading}</motion.h1>
          </AnimatePresence>
        </div>

      </div>
    </div>
  );
};

export default Navbar;
