import { useDispatch, useSelector } from "react-redux";
import { useLocation } from "react-router";
import { useEffect, useState, useMemo, useRef } from "react";
import {  changeTheme, setHeading } from "../../Slices/CommonDataSlice";
import { Menu } from "../../Routes/Routes";
import { formatData } from "../../Utils/ModuleDataFormatter";
import { LogOutUser } from "../../Actions/Authentication/Login";
import { clearUserData } from "../../Slices/UserDataSlice";
import { mutate } from "swr";
import { AnimatePresence, motion } from 'motion/react';
import { useClickOutside } from "../../Utils/Hooks/useClickOutside";
import MenuItem from "./MenuItem";
import AnimatedProfileMenu from "../AnimatedComponents/AnimatedProfileMenu";



/**
 * @author Kartik Hatwar
 * @description A reusable Sidebar component that displays a menu, user profile, and theme settings.
 * 
 * @returns {JSX.Element} The rendered Sidebar component.
 */
const Sidebar = () => {
  const { expand, theme  } = useSelector((state) => state.commonData);
  const { user, rolePermissions, roleDetails, currentWorkspace } = useSelector(state => state.userData);
  const location = useLocation();
  const dispatch = useDispatch();
  const [openProfile, setOpenProfile] = useState(false);
  const ref = useRef(null);
  const buttonRef = useRef(null);

  useClickOutside(ref, () => {
    setOpenProfile(false)
  }, buttonRef);


  const isAdmin = roleDetails?.role?.name === 'Admin';
  const permissions = formatData(rolePermissions);

  /**
   * @description A function to handle theme changes.
   * It dispatches the changeTheme action to update the theme in the Redux store.
   */
  const onChangeTheme = () => {
    dispatch(changeTheme({ name: theme.dark ? 'light' : 'dark', dark: !theme.dark }));
  }

  const toggleProfileMenu = () => setOpenProfile(v => !v)

  // Preprocess the Menu into a lookup map
  const menuLookup = useMemo(() => {
    const map = {};
    Menu.forEach((item) => {
      if (item.child) {
        item.child.forEach((childItem) => {
          map[item.link + childItem.link] = childItem.heading;
        });
      }
      map[item.link] = item.heading;
    });

    return map;
  }, []);

  // Update the heading based on the current location
  useEffect(() => {
    const heading = menuLookup[location.pathname];
    if (heading) dispatch(setHeading(heading));
    else dispatch(setHeading(''));
  }, [location.pathname, menuLookup, dispatch]);

  const clearCache = () => mutate(() => true, undefined, { revalidate: false })

  /**
   * @description An effect hook that checks if the user is logging out and clears the user data and token.
   * It also navigates the user to the homepage after logging out.
   */
  const logout = async () => {
    const res = await LogOutUser();
    if (res) {
      dispatch(clearUserData());
      clearCache();
    }
  }

  const filteredMenu = Menu?.filter(route => {

    if (isAdmin) return true; // Allow all routes for admin
    // Check if the route name exists as a key in the permissions object
    const permissionKey = permissions[route.name];
    if (permissionKey) {
      const [update, read, none] = permissionKey?.permissions?.split('')?.map(Number); // Split "110" into [1, 1, 0]
      if (update === 1 || read === 1) return true; // Allow route if update or read is 1
      if (none === 1) return false; // Exclude route if none is 1
      return false;
    }
    return false; // Exclude route if no permissions or none are allowed
  });

  const containerAnimate = {
    hidden: { opacity: 1 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  }

  const colorArray = [
    // { bg: 'bg-primary', color: 'text-primary', badge: 'badge-primary' },
    { bg: 'bg-info', color: 'text-info', badge: 'badge-info' },
    // { bg: 'bg-success', color: 'text-success', badge: 'badge-success' },
    { bg: 'bg-accent', color: 'text-accent', badge: 'badge-accent' },
    { bg: 'bg-error', color: 'text-error', badge: 'badge-error' },
    { bg: 'bg-warning', color: 'text-warning', badge: 'badge-warning' },
  ];

  const [cIndex] = useState(Math.floor(Math.random() * colorArray.length));

  const profileMenu = [
    <div onClick={onChangeTheme} className="flex py-2 px-2 mb-1 text-sm font-semibold glassMenuItem rounded-lg cursor-pointer items-center justify-between gap-6">
      <span className="text-nowrap">Dark Mode</span>
      <input
        type="checkbox"
        checked={theme.dark}
        onChange={onChangeTheme}
        className="toggle toggle-"
      />
    </div>,
    <motion.button whileTap={{ scale: 0.99 }} layout className="w-full text-nowrap rounded-lg py-1 px-2 text-md bg-red-400 dark:bg-red-500 hover:bg-base-content/30 transition-all duration-300 text-center text-white shadow-xl border-2 border-b-0 border-base-content/10 font-bold cursor-pointer" onClick={() => logout()}>
      Log Out
    </motion.button>
  ]

  return (
    <div className={`h-full bg-base-100 flex flex-col min-w-fit border-r border-base-content/10`}>
      <motion.div variants={containerAnimate} initial="hidden" animate="show" transition="transition"
        className="flex basis-10 grow flex-col w-fit gap-4 px-2 py-6 overflow-y-auto">
        {filteredMenu?.map((menuItem, i) => <MenuItem key={`menuItem_${i}`} item={menuItem} />)}
      </motion.div>

      <div className={`relative mt-auto mx-auto mb-3 `}>
        <div ref={buttonRef} onClick={toggleProfileMenu} className={`flex justify-center items-center px-1 py-1 bg-base-content/10 hover:bg-base-content/15 duration-300 border-t-2 border-x-1 border-base-content/5 cursor-pointer rounded-lg !gap-0 transition-all`}>
          <span className={`w-8 h-8 items-center justify-center flex font-bold capitalize text-xl text-white rounded-lg ${colorArray[cIndex]?.bg}`}>
            {user?.username?.slice(0, 1)}
          </span>
          <span className={`overflow-hidden transition-all duration-300 font-medium ${!expand ? "!w-0 visibility-none" : "w-30 ml-3"} font-bold `} >
            {user?.username}
          </span>
        </div>

        <AnimatePresence mode="wait">
          {
            openProfile ?
              <AnimatedProfileMenu colors={colorArray[cIndex]} {...user}
              //TODO - Remove after demo
                role={roleDetails?.role?.name ?? 'Unknown Role'}
                menuList={profileMenu} currentRef={ref} />
              : null
          }
        </AnimatePresence>
      </div>
    </div>
  )
};

export default Sidebar;
