import { useEffect, useState } from "react";
import { AuthenticateUser } from "../../Actions/Authentication/Login";
import { useDispatch, useSelector } from "react-redux";
import { updateUserData } from "../../Slices/UserDataSlice";
import { IoMdEye, IoMdEyeOff } from "react-icons/io";
import toast from "react-hot-toast";


const LoginModal = ({ toggleModal }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [see, setSee] = useState(false);
  const dispatch = useDispatch();
  const [prevUser, setPrevUser] = useState("");

  const toggleSee = () => setSee(v => !v);


  const onSubmit = async (e) => {
    e.preventDefault();
    toast.promise(AuthenticateUser(username, password), {
      loading: 'Logging In',
      success: (data) => {
        if (data.status === 'SUCCESS' || data.status === 'OK') {
          const userData = data.data;
          if (userData) {
            localStorage.setItem("prevUser", username);
            dispatch(updateUserData({
              user: userData?.userDetails,
              token: userData?.token,
              roleDetails: userData?.roleDetails,
              rolePermissions: userData?.rolePermisson
            }))
          }
        }
        else {
          toast.error(userResponse.message, { id: "loginError" })
        }
      },
      error: 'Failed To LogIn'
    })
  }

  useEffect(() => {
    const prevUsername = localStorage.getItem('prevUser');
    if (prevUsername) {
      setPrevUser(true);
      setUsername(prevUsername)
    }
  }, [])

  const clearRemember = () => {
    localStorage.removeItem("prevUser")
    setUsername("");
    setPrevUser(false);
  }

  return (
    <form data-theme="light" onSubmit={onSubmit} className="flex flex-col justify-start gap-8 items-center rounded-2xl bg-gradient-to-tr to-info/10 from-primary/4 bg-base-content/20 backdrop-blur-lg min-h-105 min-w-80 border-t-2 border-x border-base-content/20 shadow sm:mr-32 mt-20 ml-32 px-4 py-1">
      <div className="w-full flex flex-col">
        <div className="heading">
          <h5 className="text-xl font-[600] text-white text-center">Login</h5>
          <span className="w-7 h-0.75 mx-auto my-2.5 float-none block bg-green-400" />
        </div>
        <div className="fields grow flex flex-col justify-start">
          {
            prevUser ?
              (
                <div className="flex flex-col gap-2 py-2">
                  <div className="flex rounded-2xl backdrop-blur-md bg-base-content/10 hover:bg-base-content/15 transition-colors cursor-pointer px-2 py-2 items-center  gap-3">
                    <div className="h-10 aspect-square flex items-center justify-center rounded-xl bg-primary/70 uppercase text-white font-bold text-lg">{username?.slice(0, 1)}</div>
                    <div className="text-white text-lg font-semibold">{username}</div>
                  </div>
                  <div className="text-start px-1 text-xs"><span className="text-white">Other Account</span> - <span onClick={() => clearRemember()} className="text-blue-600 cursor-pointer">Click Here</span></div>
                </div>
              ) :
              (
                <div className="py-3">
                  <div>
                    <label className="input bg-base-100/70 border-t-2 border-x border-b-0 border-base-content/20 min-h-12 validator focus-within:outline-none">
                      <svg className="h-[1em] opacity-50" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" >
                        <g strokeLinejoin="round" strokeLinecap="round" strokeWidth="2.5" fill="none" stroke="currentColor" > <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4" /></g>
                      </svg>

                      <input type="input" name="username" value={username} onChange={(e) => setUsername(e.target.value)}
                        required placeholder="Username" pattern=".{5,20}" minLength="5" maxLength="20"
                        title="Must be 5 to 20 characters"
                      />
                    </label>
                    <p className="validator-hint h-4"> Must be 5 to 20 characters</p>
                  </div>
                </div>
              )
          }

          <div className="py-2">
            <label className="input bg-base-100/70 border-t-2 border-x border-b-0 border-base-content/20 min-h-12 validator focus-within:outline-none">
              <svg className="h-[1em] opacity-50" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" >
                <g strokeLinejoin="round" strokeLinecap="round" strokeWidth="2.5" fill="none" stroke="currentColor" ><path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"></path><circle cx="16.5" cy="7.5" r=".5" fill="currentColor" /></g>
              </svg>
              <input type={see ? 'text' : 'password'} name="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="Password" minLength="5" maxLength="20" pattern=".{5,20}"
                title="Must be 5 to 20 characters"
              />
              <button onClick={toggleSee} type="button" aria-label="passWordVisBtn" className="text-lg cursor-pointer hover:text-base-content/70 text-base-content/60">
                {see ? <IoMdEye /> : <IoMdEyeOff />}
              </button>
            </label>
            <p className="validator-hint h-4">Must be 5 to 20 characters</p>
          </div>
        </div>

      </div>
      <div className="w-full">
        <button type="submit" className="btn btn-primary btn-soft border-t-2 border-b-0 border-base-content/7 shadow-lg rounded-lg duration-1000 mt-auto text-lg w-full text-base-900">
          LOGIN
        </button>

        {/* <div className="flex mt-5 gap-3 pb-2 flex-wrap text-sm font-semibold justify-center">
          <span className="text-center text-white">Don&apos;t have account ?</span>
          <button onClick={() => toggleModal()} className="text-primary cursor-pointer hover:text-primary">Sign Up</button>
        </div> */}
      </div>
    </form>
  )
}

export default LoginModal;